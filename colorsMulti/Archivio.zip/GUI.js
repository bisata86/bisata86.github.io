//var socket = io.connect('http://192.168.1.4:3000');
var socket = io.connect('http://skeletrons.herokuapp.com:80');

var Game = {
	'play' : false
}

function GUI(){
	var _this 	   = this;
	var rowTiles   = 5;
	var pixelDimension = 100/rowTiles+'%';


	function elementPos(x,y) {
        var pass = rowTiles*(rowTiles-1-y)+x;
        return pass;
    }

    function detectmob() {
		if( navigator.userAgent.match(/Android/i)
			|| navigator.userAgent.match(/webOS/i)
			|| navigator.userAgent.match(/iPhone/i)
			|| navigator.userAgent.match(/iPad/i)
			|| navigator.userAgent.match(/iPod/i)
			|| navigator.userAgent.match(/BlackBerry/i)
			|| navigator.userAgent.match(/Windows Phone/i)
		){
			return true;
		}else {
			return false;
		}
    }

    function colorClick(){
    	if(Game.play == true){
	        var colorT = $(this).attr('id');
	        socket.emit('player_move', {'color': colorT});
	        Game.play = false;
        }else{
        	alert('no');
        }
    }

    function createGame(){
    	socket.emit('create_game', {});
    }
    function showJoinGame(){
  		$('#game_intro').hide();
		$('#game_join').show();
    }

    function joinGame(){
    	var _gid = $('#join_id').val();
    	socket.emit('join_game', {'gid':_gid});
    }
    function joinRandomGame(){
    	$('#mp_home').hide();
    	socket.emit('player_join', {});
    }

    this.showJoinErr = function(data){
    	$('#game_join .error').html(data.err);
    }

    this.showGameID = function(data){
    	console.log('asds '+data)
  		$('#game_intro').hide();
		$('#game_id').show()
		$('#game_id .code').html(data.gid);
    }

	this.updateGrid = function(_grid){
		for(var ki = 0; ki < rowTiles; ki++) {
            for(var k = 0; k < rowTiles; k++) {
                var optimize = $( ".pixel:eq("+elementPos(ki,k)+")" );
                optimize.attr('class', 'pixel '+_grid[ki][k][0]);
            }
        }
	}

	this.drawGrid = function(_grid){
		$('#grid').html('');
		$('#mp_home').hide();
	    var basestructure = "<div class='pixel'></div>";
	    var structure = "";

	    for(var ki=0; ki < rowTiles; ki++) {
	        for(var k=0; k < rowTiles; k++) {
	            structure = structure + basestructure;
	        }
	    }
	    $('#grid').append(structure);

		for(var ki = 0; ki < rowTiles; ki++) {
            for(var k = 0; k < rowTiles; k++) {
                var optimize = $( ".pixel:eq("+elementPos(ki,k)+")" );
                optimize.attr('class', 'pixel '+_grid[ki][k][0]);

            }
        }
        $(".pixel:eq(0)" ).attr('class', 'pixel player1');
        $(".pixel:eq("+((rowTiles*rowTiles)-1)+")" ).attr('class', 'pixel player2');
        $(".pixel" ).each(function( index ) {
              $(this).css({
                height: pixelDimension,
                width: pixelDimension
              });
        });

        if ($(window).width() > $(window).height()) {
	        $('body').addClass('landscape');
	        $('body').removeClass('portrait');
	    }else {
	        $('body').removeClass('landscape');
	        $('body').addClass('portrait');
	    }
	}

	this.updatePower = function(_col){
		$('.power.disabled').removeClass('disabled');
		$('#'+_col).addClass('disabled');
	}

	this.init = function(){
		$('body').addClass('noFb');
		$('body').addClass('gaming');
		if(detectmob()) {
	        $('body').addClass('mobile');
	        clickType = 'touchstart';
	    }  else {
	        $('body').addClass('desktop');
	        clickType = 'click';
	    }

        $(".power").on(clickType, colorClick);
        $("#create_game").on(clickType, createGame);
        $("#join_game").on(clickType,  showJoinGame);
        $("#join_random").on(clickType,joinRandomGame);
        $("#submit_join").on(clickType,  joinGame);

	}
}

function init(){
	var gui = new GUI();
		gui.init();

	socket.on('game-start', gui.drawGrid);
   	socket.on('grid-update', function(data){
		gui.updateGrid(data.grid);
		gui.updatePower(data.color);
		Game.play = false;
    });
  	socket.on('game-turn', function(data){
		Game.play = true;
    });
  	socket.on('join-err', gui.showJoinErr);
  	socket.on('game-pending',gui.showGameID);
}

$(document).ready(init);